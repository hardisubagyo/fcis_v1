<style type="text/css">
	.offscreen {
	    position: absolute;
	    left: -999em;
	}
</style>


<?php $__env->startSection('titleheadercontent'); ?>
	<h2>Dashboard</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headercontent'); ?>
	<ol class="breadcrumbs">
		<li>
			<a href="<?php echo e(url('dashboard')); ?>">
				<i class="fa fa-bars" aria-hidden="true"></i>
			</a>
		</li>
		<li><span>List Skenario</span></li>
	</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="panel">
		<header class="panel-heading">
			<div class="panel-actions">
				<a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
			</div>
	
			<h2 class="panel-title">List Skenario</h2>
		</header>
		<div class="panel-body">
			<p>
				<a href="<?php echo e(url('createSkenario')); ?>">
					<button type="button" class="mb-xs mt-xs mr-xs btn btn-primary">Tambah Skenario</button>	
				</a>
			</p>

			<?php if(Session::has('success')): ?>
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong>Sukses</strong> <?php echo e(Session::get('success')); ?>

				</div>
	        <?php endif; ?>
			
			<table class="table table-bordered table-striped mb-none" id="MenuTable">
				<thead>
					<tr>
						<th>No</th>
						<th>Scenario</th>
						<th>Create Date</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $no = 1; ?>
					<?php $__currentLoopData = $skenario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($no++); ?></td>
							<td><?php echo e($item->nama); ?></td>
							<td><?php echo e($item->created_at); ?></td>
							<td>
								<a href="<?php echo e(url('editSkenario/'.$item->id)); ?>">
									<button type="button" class="mb-xs mt-xs mr-xs btn btn-xs btn-warning"> Edit </button>
								</a>
								<form action="<?php echo e(route('Skenario.destroy', $item->id)); ?>" method="GET" style="display:inline-block;">
                                    <button title="Delete" onclick="return confirm('Anda yakin ?')" class="mb-xs mt-xs mr-xs btn btn-xs btn-danger" type="submit">Delete</button>
                                </form>
								<a href="<?php echo e(url('showFlight/'.$item->id)); ?>">
									<button type="button" class="mb-xs mt-xs mr-xs btn btn-xs btn-success"> Detail </button>
								</a>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<script>
	function copyText(id) {
  		var copyText = document.getElementById("url-"+id);
  		copyText.select();
  		document.execCommand("copy");
  		alert("Copied the text: " + copyText.value);
  		 
	}
</script>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fcis_1\resources\views/layouts/skenario/index.blade.php ENDPATH**/ ?>