<style type="text/css">
  .offscreen {
      position: absolute;
      left: -999em;
  }
</style>

<!-- <link rel="stylesheet" href="<?php echo e(asset('leaflet/leaflet.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('leaflet/leaflet.label.css')); ?>">
<script src="<?php echo e(asset('leaflet/leaflet.js')); ?>"></script>
<script src="<?php echo e(asset('leaflet/leaflet.label.js')); ?>"></script>
<script src="<?php echo e(asset('leaflet/Leaflet.TileLayer.MBTiles.js')); ?>"></script>
<script src="<?php echo e(asset('leaflet/sql.js')); ?>"></script> -->
<!-- <script src="<?php echo e(asset('leaflet/leaflet-src.js')); ?>"></script> -->

<link href="<?php echo e(asset('leaflet_v1/leaflet.css')); ?>" rel="stylesheet" type="text/css" />
<script src="<?php echo e(asset('leaflet_v1/leaflet-src.js')); ?>"></script>
<script src="<?php echo e(asset('leaflet_v1/sql.js')); ?>"></script>
<script src="<?php echo e(asset('leaflet_v1/Leaflet.TileLayer.MBTiles.js')); ?>"></script>
<script src="<?php echo e(asset('leaflet/leaflet.label.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('leaflet/leaflet.js')); ?>"></script> -->

<script src="<?php echo e(asset('showWaypoint/indonesia.json')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('showWaypoint/ibukota_provinsi.json')); ?>" type="text/javascript"></script>



<?php $__env->startSection('titleheadercontent'); ?>
    <h2>Dashboard</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headercontent'); ?>
    <ol class="breadcrumbs">
        <li>
            <a href="<?php echo e(url('dashboard')); ?>">
                <i class="fa fa-bars" aria-hidden="true"></i>
            </a>
        </li>
        <li><span>Waypoint</span></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="panel">
        <header class="panel-heading">
            <div class="panel-actions">
                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
            </div>
            <h2 class="panel-title">
            <a href="<?php echo e(url('Skenario')); ?>"> <?php echo e($flight->nama); ?> </a> | 
            <a href="<?php echo e(url('showFlight/'.$flight->id_flight_url)); ?>">
                Callsign : <?php echo e($flight->callsign); ?> | Delay : <?php echo e($flight->delay); ?> 
            </a> | 
            <a href="<?php echo e(url('showRoute/'.$flight->id_route_url)); ?>"><?php echo e($route->name); ?> </a></h2>
        </header>
        <div class="panel-body">
            
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <strong>Sukses</strong> <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered table-striped mb-none" id="MenuTable">
                        <thead>
                          <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>X</th>
                            <th>Y</th>
                            <th>Alt</th>
                            <th>Speed</th>
                            <th>Delay</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $no = 1; ?>
                          <?php $__currentLoopData = $waypoint; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->x); ?></td>
                                <td><?php echo e($item->y); ?></td>
                                <td><?php echo e($item->alt); ?></td>
                                <td><?php echo e($item->speed); ?></td>
                                <td><?php echo e($item->delay); ?></td>
                                <td>
                                    <form action="<?php echo e(route('Waypoint.destroy', $item->id)); ?>" method="GET" style="display:inline-block;">
                                        <button title="Delete" onclick="return confirm('Anda yakin ?')" class="mb-xs mt-xs mr-xs btn btn-xs btn-danger" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="col-md-6">
                    <div id="mapid" style="width: 100%; height: 400px;"></div>

                    <script>
                        var mymap = L.map('mapid', {minZoom: 0,maxZoom: 6}).setView([-4.907389, 115.169578], 4);

                        var mb = L.tileLayer.mbTiles('./countries-raster.mbtiles').addTo(mymap);

                        L.geoJSON(provinsi,{
                            style: {
                                weight: 1,
                                color: "#000",
                                opacity: 1,
                                fillColor: "#B0DE5C",
                                fillOpacity: 0.8
                            }
                        }).addTo(mymap);

                        L.geoJSON(ibukota_provinsi, {
                            pointToLayer: function (feature, latlng) {
                                return L.circleMarker(latlng, {
                                    radius: 2,
                                    fillColor: "#ff7800",
                                    color: "#000",
                                    weight: 1,
                                    opacity: 1,
                                    fillOpacity: 0.8
                                });
                            }
                        }).addTo(mymap);

                        var myStyle = {
                            "color": "#000",
                            "weight": 1,
                            "opacity": 0.65
                        };

                        mb.on('databaseloaded', function(ev) {
                            console.info('MBTiles DB loaded', ev);
                        });
                        mb.on('databaseerror', function(ev) {
                            console.info('MBTiles DB error', ev);
                        });

                        mymap.on('dblclick', function(e){
                            var coord = e.latlng;
                            var lat = coord.lat;
                            var lng = coord.lng;

                            document.getElementById("x").value = lat;
                            document.getElementById("y").value = lng;
                            $('#modalPrimary').modal('show');
                        });

                        L.polyline([
                            <?php foreach($waypoint as $item){ ?>
                                [<?php echo $item->x; ?>, <?php echo $item->y; ?>],
                            <?php } ?>
                            ],{ weight: 2, color: '#0D0C0C' }).addTo(mymap);

                        <?php 
                            foreach($waypoint as $item){
                        ?>
                            L.marker([<?php echo $item->x; ?>, <?php echo $item->y; ?>]).addTo(mymap);
                        <?php } ?>
                    </script>

                    <div class="modal fade" id="modalPrimary" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form id="form1" method="post" class="form-horizontal" action="<?php echo e(route('Waypoint.store')); ?>" enctype="multipart/form-data">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Tambah Waypoint</h5>
                                    </div>
                                    <div class="modal-body">
                                        <?php echo e(csrf_field()); ?>

                                        <section class="panel">
                                            <div class="panel-body">
                                                <?php if(Session::has('danger')): ?>
                                                    <div class="alert alert-danger">
                                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                                        <strong>Gagal</strong> <?php echo e(Session::get('danger')); ?>

                                                    </div>
                                                <?php endif; ?>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Nama </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="name" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">X </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="x" class="form-control" id="x" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Y </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="y" id="y" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Alt </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="alt" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Speed </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="speed" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Delay </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="delay" class="form-control" required>
                                                    </div>
                                                </div>
                                                
                                                <input type="hidden" name="id_route" value="<?php echo e($id_route); ?>">
                                                <input type="hidden" name="id_flight" value="<?php echo e($route->id_flight); ?>">
                                                <input type="hidden" name="id_skenario" value="<?php echo e($route->id_skenario); ?>">
                                                
                                            </div>
                                            <footer class="panel-footer">
                                                <button class="btn btn-primary">Simpan </button>
                                                <button type="reset" class="btn btn-default">Reset</button>
                                            </footer>
                                        </section>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fcis_1\resources\views/layouts/waypoint/index.blade.php ENDPATH**/ ?>