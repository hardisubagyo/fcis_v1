<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Skenario extends Model
{
    protected $table = 'scenario';
}
