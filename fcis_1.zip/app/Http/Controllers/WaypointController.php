<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Models\Skenario;
use App\Models\Flight;
use App\Models\Route;
use App\Models\Waypoint;

class WaypointController extends Controller
{
    public function __construct()
    {
        $this->middleware('cekstatus');
    }

    public function waypoint($id){
    	$flight = DB::table('route')
    				->select(
    					'flight.callsign', 
    					'flight.delay', 
    					'flight.id_skenario as id_flight_url' , 
    					'flight.id as id_route_url' , 
    					'scenario.nama'
    				)
    				->join('flight', 'flight.id', '=', 'route.id_flight')
    				->join('scenario', 'scenario.id', '=', 'flight.id_skenario')
    				->where('route.id', $id)
    				->first();
    	$route = Route::where('id', $id)->first();

    	$waypoint = Waypoint::where('id_route', $id)->get();
    	return view('layouts/waypoint/index',['id_route' => $id, 'waypoint' => $waypoint, 'route' => $route, 'flight' => $flight]);
    }

    public function create($id){
        $route = Route::where('id', $id)->first();
    	return view('layouts/waypoint/tambah',['id_route' => $id, 'route' => $route]);
    }

    public function store(Request $request){
	
		$data= new Waypoint();
	    $data->x=$request->get('x');
	    $data->y=$request->get('y');
	    $data->alt=$request->get('alt');
	    $data->speed=$request->get('speed');
	    $data->delay=$request->get('delay');
	    $data->name=$request->get('name');
	    $data->id_route=$request->get('id_route');
        $data->id_flight=$request->get('id_flight');
        $data->id_skenario=$request->get('id_skenario');
	    $data->save();

	    return redirect('/showWaypoint/'.$request->get('id_route'))->with('success', 'Waypoint berhasil tersimpan');
    }

    public function destroy($id){
    	$data= Waypoint::find($id);
        Waypoint::find($id)->delete();
        return redirect('/showWaypoint/'.$data->id_route)->with('success', 'Waypoint berhasil dihapus');
    }
}
