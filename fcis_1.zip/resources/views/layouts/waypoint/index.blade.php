<style type="text/css">
  .offscreen {
      position: absolute;
      left: -999em;
  }
</style>

<!-- <link rel="stylesheet" href="{{ asset('leaflet/leaflet.css') }}">
<link rel="stylesheet" href="{{ asset('leaflet/leaflet.label.css') }}">
<script src="{{ asset('leaflet/leaflet.js') }}"></script>
<script src="{{ asset('leaflet/leaflet.label.js') }}"></script>
<script src="{{ asset('leaflet/Leaflet.TileLayer.MBTiles.js') }}"></script>
<script src="{{ asset('leaflet/sql.js') }}"></script> -->
<!-- <script src="{{ asset('leaflet/leaflet-src.js') }}"></script> -->

<link href="{{ asset('leaflet_v1/leaflet.css') }}" rel="stylesheet" type="text/css" />
<script src="{{ asset('leaflet_v1/leaflet-src.js') }}"></script>
<script src="{{ asset('leaflet_v1/sql.js') }}"></script>
<script src="{{ asset('leaflet_v1/Leaflet.TileLayer.MBTiles.js') }}"></script>
<script src="{{ asset('leaflet/leaflet.label.js') }}"></script>
<!-- <script src="{{ asset('leaflet/leaflet.js') }}"></script> -->

<script src="{{ asset('showWaypoint/indonesia.json') }}" type="text/javascript"></script>
<script src="{{ asset('showWaypoint/ibukota_provinsi.json') }}" type="text/javascript"></script>

@extends('layouts.dashboard')

@section('titleheadercontent')
    <h2>Dashboard</h2>
@endsection

@section('headercontent')
    <ol class="breadcrumbs">
        <li>
            <a href="{{ url('dashboard')}}">
                <i class="fa fa-bars" aria-hidden="true"></i>
            </a>
        </li>
        <li><span>Waypoint</span></li>
    </ol>
@endsection

@section('content')
    <section class="panel">
        <header class="panel-heading">
            <div class="panel-actions">
                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
            </div>
            <h2 class="panel-title">
            <a href="{{ url('Skenario') }}"> {{ $flight->nama }} </a> | 
            <a href="{{ url('showFlight/'.$flight->id_flight_url) }}">
                Callsign : {{ $flight->callsign }} | Delay : {{ $flight->delay }} 
            </a> | 
            <a href="{{ url('showRoute/'.$flight->id_route_url) }}">{{ $route->name }} </a></h2>
        </header>
        <div class="panel-body">
            {{-- <p>
                <a href="{{ url('createWaypoint/'.$id_route) }}">
                    <button type="button" class="mb-xs mt-xs mr-xs btn btn-primary">Tambah Waypoint</button>  
                </a>
            </p>
            --}}
            @if (Session::has('success'))
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <strong>Sukses</strong> {{ Session::get('success') }}
                </div>
            @endif
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered table-striped mb-none" id="MenuTable">
                        <thead>
                          <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>X</th>
                            <th>Y</th>
                            <th>Alt</th>
                            <th>Speed</th>
                            <th>Delay</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          @php $no = 1; @endphp
                          @foreach($waypoint as $item)
                            <tr>
                                <td>{{ $no++ }}</td>
                                <td>{{ $item->name }}</td>
                                <td>{{ $item->x }}</td>
                                <td>{{ $item->y }}</td>
                                <td>{{ $item->alt }}</td>
                                <td>{{ $item->speed }}</td>
                                <td>{{ $item->delay }}</td>
                                <td>
                                    <form action="{{ route('Waypoint.destroy', $item->id) }}" method="GET" style="display:inline-block;">
                                        <button title="Delete" onclick="return confirm('Anda yakin ?')" class="mb-xs mt-xs mr-xs btn btn-xs btn-danger" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                          @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="col-md-6">
                    <div id="mapid" style="width: 100%; height: 400px;"></div>

                    <script>
                        var mymap = L.map('mapid', {minZoom: 0,maxZoom: 6}).setView([-4.907389, 115.169578], 4);

                        var mb = L.tileLayer.mbTiles('./countries-raster.mbtiles').addTo(mymap);

                        L.geoJSON(provinsi,{
                            style: {
                                weight: 1,
                                color: "#000",
                                opacity: 1,
                                fillColor: "#B0DE5C",
                                fillOpacity: 0.8
                            }
                        }).addTo(mymap);

                        L.geoJSON(ibukota_provinsi, {
                            pointToLayer: function (feature, latlng) {
                                return L.circleMarker(latlng, {
                                    radius: 2,
                                    fillColor: "#ff7800",
                                    color: "#000",
                                    weight: 1,
                                    opacity: 1,
                                    fillOpacity: 0.8
                                });
                            }
                        }).addTo(mymap);

                        var myStyle = {
                            "color": "#000",
                            "weight": 1,
                            "opacity": 0.65
                        };

                        mb.on('databaseloaded', function(ev) {
                            console.info('MBTiles DB loaded', ev);
                        });
                        mb.on('databaseerror', function(ev) {
                            console.info('MBTiles DB error', ev);
                        });

                        mymap.on('dblclick', function(e){
                            var coord = e.latlng;
                            var lat = coord.lat;
                            var lng = coord.lng;

                            document.getElementById("x").value = lat;
                            document.getElementById("y").value = lng;
                            $('#modalPrimary').modal('show');
                        });

                        L.polyline([
                            <?php foreach($waypoint as $item){ ?>
                                [<?php echo $item->x; ?>, <?php echo $item->y; ?>],
                            <?php } ?>
                            ],{ weight: 2, color: '#0D0C0C' }).addTo(mymap);

                        <?php 
                            foreach($waypoint as $item){
                        ?>
                            L.marker([<?php echo $item->x; ?>, <?php echo $item->y; ?>]).addTo(mymap);
                        <?php } ?>
                    </script>

                    <div class="modal fade" id="modalPrimary" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form id="form1" method="post" class="form-horizontal" action="{{ route('Waypoint.store') }}" enctype="multipart/form-data">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Tambah Waypoint</h5>
                                    </div>
                                    <div class="modal-body">
                                        {{ csrf_field() }}
                                        <section class="panel">
                                            <div class="panel-body">
                                                @if (Session::has('danger'))
                                                    <div class="alert alert-danger">
                                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                                        <strong>Gagal</strong> {{ Session::get('danger') }}
                                                    </div>
                                                @endif

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Nama </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="name" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">X </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="x" class="form-control" id="x" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Y </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="y" id="y" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Alt </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="alt" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Speed </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="speed" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Delay </label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="delay" class="form-control" required>
                                                    </div>
                                                </div>
                                                
                                                <input type="hidden" name="id_route" value="{{ $id_route }}">
                                                <input type="hidden" name="id_flight" value="{{ $route->id_flight }}">
                                                <input type="hidden" name="id_skenario" value="{{ $route->id_skenario }}">
                                                
                                            </div>
                                            <footer class="panel-footer">
                                                <button class="btn btn-primary">Simpan </button>
                                                <button type="reset" class="btn btn-default">Reset</button>
                                            </footer>
                                        </section>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection