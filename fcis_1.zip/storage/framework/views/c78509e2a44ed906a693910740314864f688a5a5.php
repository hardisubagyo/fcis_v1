<style type="text/css">
	.offscreen {
	    position: absolute;
	    left: -999em;
	}
</style>

<link rel="stylesheet" href="<?php echo e(asset('leaflet/leaflet.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('leaflet/leaflet.label.css')); ?>">

<script src="<?php echo e(asset('leaflet/leaflet.js')); ?>"></script>
<script src="<?php echo e(asset('leaflet/leaflet.label.js')); ?>"></script>
<script src="<?php echo e(asset('leaflet/leaflet-providers.js')); ?>"></script>




<?php $__env->startSection('titleheadercontent'); ?>
	<h2>Dashboard</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headercontent'); ?>
	<ol class="breadcrumbs">
		<li>
			<a href="<?php echo e(url('dashboard')); ?>">
				<i class="fa fa-bars" aria-hidden="true"></i>
			</a>
		</li>
		<li><span>Waypoint</span></li>
	</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="panel">
		<header class="panel-heading">
			<div class="panel-actions">
				<a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
			</div>
			<h2 class="panel-title">
				<a href="<?php echo e(url('Skenario')); ?>"> <?php echo e($flight->nama); ?> </a> | 
				<a href="<?php echo e(url('showFlight/'.$flight->id_flight_url)); ?>">Callsign : <?php echo e($flight->callsign); ?> | Delay : <?php echo e($flight->delay); ?> </a> | 
				<a href="<?php echo e(url('showRoute/'.$flight->id_route_url)); ?>"><?php echo e($route->name); ?> </a></h2>
		</header>
		<div class="panel-body">
			<p>
				<a href="<?php echo e(url('createWaypoint/'.$id_route)); ?>">
					<button type="button" class="mb-xs mt-xs mr-xs btn btn-primary">Tambah Waypoint</button>	
				</a>
			</p>

			<?php if(Session::has('success')): ?>
				<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong>Sukses</strong> <?php echo e(Session::get('success')); ?>

				</div>
	        <?php endif; ?>
	        <div class="row">
	        	<div class="col-md-6">
					<table class="table table-bordered table-striped mb-none" id="MenuTable">
						<thead>
							<tr>
								<th>No</th>
								<th>Name</th>
								<th>X</th>
								<th>Y</th>
								<th>Alt</th>
								<th>Speed</th>
								<th>Delay</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $no = 1; ?>
							<?php $__currentLoopData = $waypoint; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($no++); ?></td>
									<td><?php echo e($item->name); ?></td>
									<td><?php echo e($item->x); ?></td>
									<td><?php echo e($item->y); ?></td>
									<td><?php echo e($item->alt); ?></td>
									<td><?php echo e($item->speed); ?></td>
									<td><?php echo e($item->delay); ?></td>
									<td>
										<form action="<?php echo e(route('Waypoint.destroy', $item->id)); ?>" method="GET" style="display:inline-block;">
		                                    <button title="Delete" onclick="return confirm('Anda yakin ?')" class="mb-xs mt-xs mr-xs btn btn-xs btn-danger" type="submit">Delete</button>
		                                </form>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
				<div class="col-md-6">
					<div id="mapid" style="width: 100%; height: 400px;"></div>

					<script>
						var mymap = L.map('mapid').setView([-4.907389, 115.169578], 4);

						L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
							maxZoom: 18,
							attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
								'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
								'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
							id: 'mapbox.streets'
						}).addTo(mymap);

						L.polyline([
								<?php foreach($waypoint as $item){ ?>
									[<?php echo $item->x; ?>, <?php echo $item->y; ?>],
								<?php } ?>
								],{ weight: 5, color: '#FFD700' }).addTo(mymap);

						<?php 
							foreach($waypoint as $item){
						?>
								L.marker([<?php echo $item->x; ?>, <?php echo $item->y; ?>]).bindLabel('<?php echo $item->name; ?>', { noHide: true }).addTo(mymap).showLabel();
						<?php 
							}
						?>
					</script>
				</div>
	        </div>
			
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fcis\resources\views/layouts/waypoint/index.blade.php ENDPATH**/ ?>