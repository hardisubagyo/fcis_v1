<style type="text/css">
	.offscreen {
	    position: absolute;
	    left: -999em;
	}
</style>


<?php $__env->startSection('titleheadercontent'); ?>
	<h2>Dashboard</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headercontent'); ?>
	<ol class="breadcrumbs">
		<li>
			<a href="<?php echo e(url('dashboard')); ?>">
				<i class="fa fa-bars" aria-hidden="true"></i>
			</a>
		</li>
	</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="panel">
		<header class="panel-heading">
			<div class="panel-actions">
				<a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
			</div>
	
			<h2 class="panel-title">Dashboard</h2>
		</header>
		
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fcis_1\resources\views/layouts/dashboard/index.blade.php ENDPATH**/ ?>