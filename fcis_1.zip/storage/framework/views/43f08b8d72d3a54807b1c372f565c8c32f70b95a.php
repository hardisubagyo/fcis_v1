<?php $__env->startSection('titleheadercontent'); ?>
	<h2>Dashboard</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headercontent'); ?>
	<ol class="breadcrumbs">
		<li>
			<a href="<?php echo e(url('dashboard')); ?>">
				<i class="fa fa-bars" aria-hidden="true"></i>
			</a>
		</li>
		<li><span>Skenario</span></li>
		<li><span>Tambah</span></li>
	</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="col-md-12">
		<form id="form1" method="post" class="form-horizontal" action="<?php echo e(route('Skenario.store')); ?>" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="panel-action panel-action-toggle" data-panel-toggle=""></a>
					</div>

					<h2 class="panel-title">Tambah Skenario</h2>
				</header>
				<div class="panel-body">
					<?php if(Session::has('danger')): ?>
						<div class="alert alert-danger">
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
							<strong>Gagal</strong> <?php echo e(Session::get('danger')); ?>

						</div>
			        <?php endif; ?>

					<div class="form-group">
						<label class="col-sm-2 control-label">Nama </label>
						<div class="col-sm-6">
							<input type="text" name="nama" class="form-control" required>
						</div>
					</div>
					
				</div>
				<footer class="panel-footer">
					<button class="btn btn-primary">Simpan </button>
					<button type="reset" class="btn btn-default">Reset</button>
				</footer>
			</section>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fcis\resources\views/layouts/skenario/tambah.blade.php ENDPATH**/ ?>